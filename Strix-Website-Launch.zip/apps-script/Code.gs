/**
 * Strix Technical Services: website request form handler.
 *
 * Lives inside the "Strix Leads" Google Sheet (Extensions > Apps Script).
 * Every request from strixtechnical.com becomes one row on the "Requests" tab
 * and one email to NOTIFY_TO. Reply to that email and it goes to the requester.
 *
 * Setup: run setup() once, then Deploy > New deployment > Web app,
 * Execute as: Me, Who has access: Anyone. Copy the web app URL into the site.
 */

const NOTIFY_TO = 'mterry@strixtechnical.com';
const SHEET_NAME = 'Requests';

// [form field name, column / email label] in the order they appear on the site
const FIELDS = [
  ['service', 'Project type'],
  ['name', 'Name'],
  ['company', 'Company or bank'],
  ['email', 'Email'],
  ['phone', 'Phone'],
  ['needed_by', 'Needed by'],
  ['site', 'Project location'],
  ['message', 'Details'],
];

function doPost(e) {
  const p = (e && e.parameter) || {};

  // Honeypot: the site hides a "website" field from people. Bots fill it in.
  if (clean_(p.website)) return json_({ result: 'success' });

  const v = {};
  FIELDS.forEach(function (f) { v[f[0]] = clean_(p[f[0]]); });
  if (!v.service || !v.name || !isEmail_(v.email)) {
    return json_({ result: 'error', message: 'Project type, name, and a valid email are required.' });
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    sheet_().appendRow([new Date()].concat(FIELDS.map(function (f) { return safe_(v[f[0]]); })));
  } finally {
    lock.releaseLock();
  }

  // The row is saved either way; a mail hiccup should not tell the visitor it failed.
  try { notify_(v); } catch (err) { console.error(err); }

  return json_({ result: 'success' });
}

// Opening the web app URL in a browser shows this, which confirms it is deployed.
function doGet() {
  return ContentService.createTextOutput('Strix request form endpoint is running.');
}

// Run once from the editor: creates the Requests tab and sends a test email.
function setup() {
  sheet_();
  MailApp.sendEmail(NOTIFY_TO, 'Strix form setup test',
    'The Strix website form is connected. New requests will land in the "' +
    SHEET_NAME + '" tab of ' + SpreadsheetApp.getActive().getUrl());
}

function sheet_() {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(['Received'].concat(FIELDS.map(function (f) { return f[1]; })));
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, FIELDS.length + 1).setFontWeight('bold');
  }
  return sh;
}

function notify_(v) {
  const lines = FIELDS.map(function (f) { return f[1] + ': ' + (v[f[0]] || '-'); });
  MailApp.sendEmail({
    to: NOTIFY_TO,
    replyTo: v.email,
    subject: 'Strix request: ' + v.service + ' from ' + v.name + (v.company ? ' (' + v.company + ')' : ''),
    body: lines.join('\n') + '\n\nLogged in: ' + SpreadsheetApp.getActive().getUrl(),
  });
}

function clean_(x) {
  return String(x == null ? '' : x).trim().slice(0, 5000);
}

function isEmail_(x) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x);
}

// Stop a submission from being read as a spreadsheet formula.
function safe_(x) {
  return /^[=+\-@]/.test(x) ? "'" + x : x;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
